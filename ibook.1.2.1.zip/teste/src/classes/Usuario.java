package classes;



public class Usuario {
	private String datanascimento;
	private String nome,matricula,celular,telefone,email,senha;
	
	
	
	public Usuario (String nome, String matricula, String celular, String telefone, String email,String datanascimento,String senha){
		super();
		this.datanascimento = datanascimento;
		this.nome = nome;
		this.matricula = matricula;
		this.celular = celular;
		this.telefone = telefone;
		this.email = email;
		this.senha = senha;
	}
	public String getDatanascimento() {
		return datanascimento;
	}
	public void setDatanascimento(String datanascimento) {
		this.datanascimento = datanascimento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	

}
