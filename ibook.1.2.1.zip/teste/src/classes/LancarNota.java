package classes;

public class LancarNota {
	private String numerodanota,isbn,quantidade,valor,data;
	
	

	public LancarNota(String numerodanota, String isbn, String quantidade, String valor, String data) {
		super();
		this.numerodanota = numerodanota;
		this.isbn = isbn;
		this.quantidade = quantidade;
		this.valor = valor;
		this.data = data;
	}

	public String getNumerodanota() {
		return numerodanota;
	}

	public void setNumerodanota(String numerodanota) {
		this.numerodanota = numerodanota;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	

}
