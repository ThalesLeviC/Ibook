package classes;

public class Reserva {
	private String isbn,matricula,dataretirada,datadevolu��o,nome;

	public Reserva(String isbn, String matricula, String dataretirada, String datadevolu��o,String nome) {
		super();
		this.isbn = isbn;
		this.matricula = matricula;
		this.dataretirada = dataretirada;
		this.datadevolu��o = datadevolu��o;
		this.nome=nome;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getDataretirada() {
		return dataretirada;
	}

	public void setDataretirada(String dataretirada) {
		this.dataretirada = dataretirada;
	}

	public String getDatadevolu��o() {
		return datadevolu��o;
	}

	public void setDatadevolu��o(String datadevolu��o) {
		this.datadevolu��o = datadevolu��o;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
	

}
