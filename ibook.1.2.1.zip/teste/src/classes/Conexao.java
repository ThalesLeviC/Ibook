package classes;

import java.sql.*;

public class Conexao {
	public static Connection getConexao(){
		//Faz a instacia dos objetos
		java.sql.Connection con;
		

		con = null;
		
		
		//Local do Banco de Dados
		String url = "jdbc:mysql://127.0.0.1:3306/biblioteca?zeroDateTimeBehavior=convertToNull";
		//meu usu�rio
		String id = "root";
		//Minha senha
		String pass = "";
		
	try{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		con = java.sql.DriverManager.getConnection(url, id, pass);
		System.out.print("foi");
	}catch(Exception e){
		System.out.print("n�o foi ");	
	}
		
		return con;
		}

	
	}


