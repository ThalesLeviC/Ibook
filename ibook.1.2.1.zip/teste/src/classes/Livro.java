package classes;

public class Livro {
	
	private String assunto,autor,isbn,nome,status,url;
	private int quantidade;

	public Livro(String assunto, String autor, String isbn, String nome, String status, String url,int quantidade ) {
		super();
		this.assunto = assunto;
		this.autor = autor;
		this.isbn = isbn;
		this.nome = nome;
		this.status = status;
		this.url = url;
		this.quantidade= quantidade;
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

}
