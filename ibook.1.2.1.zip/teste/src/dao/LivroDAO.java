package dao;
import java.sql.*;
import java.util.List;

import classes.*;

public class LivroDAO {
	
	public static String inserir(Livro livro, Connection con){
		try{
			  
			PreparedStatement st = con.prepareStatement("INSERT INTO `livro`(`isbn`, `nome`, `autor`, `assunto`, `status`, `url`,`quantidade`) VALUES (?,?,?,?,?,?,?);");
			st.setString(1,livro.getIsbn() );
			st.setString(2,livro.getNome() );
			st.setString(3,livro.getAutor() );
			st.setString(4,livro.getAssunto() );
			st.setString(5,livro.getStatus() );
			st.setString(6,livro.getUrl() );
			st.setInt(7,livro.getQuantidade());
			st.execute();
			
			
			return "Cadastro efetuado com sucesso!!!";
			
			
		}catch(Exception e){
			
			return e.toString();
			
		}
		
	}
	
		

	
	public static List<Livro> buscar(String nome, Connection con){
		try{

		List<Livro> livros = null;
		String sql = "SELECT `nome`,`status`,`url` FROM `livro` WHERE nome = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1,nome);
		ResultSet resultado = st.executeQuery();
		while(resultado.next()){

		Livro livro = new Livro(sql, sql, sql, sql, sql, sql, 0);
		livro.setStatus(resultado.getString("nome"));
		livro.setUrl(resultado.getString("url"));
		livro.setStatus(resultado.getString("status"));
		livros.add(livro);
		return livros;

		}
		}catch(Exception e){
		System.out.print(e);
		return null;

		}
		return null;	

		}


}
