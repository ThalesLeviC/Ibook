package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import classes.Conexao;
import classes.Reserva;

public class ReservaDAO {
	
	
	
	
	public static String devolver(int numeroReserva,String isbn,String matricula) throws SQLException{
		
		try{
		Connection con = Conexao.getConexao();
		
		 String sql4 = "SELECT `nome` FROM `reserva` WHERE `matricula`='"+matricula+"'";
			PreparedStatement st4 = con.prepareStatement(sql4);
			ResultSet result = st4.executeQuery();
			String nomelivro = null;
			while(result.next()){
				 nomelivro = result.getString("nome");
			
				
			}
			
			 Date dataAtual = new Date(); 
		      SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		      String dataStr = sdf.format(dataAtual);
		      
		      java.util.GregorianCalendar gc = new java.util.GregorianCalendar();
			String datadevolucao = new java.text.SimpleDateFormat("dd/MM/yyyy").format(gc.getTime());
		      
			
			String sql5 = "INSERT INTO `notificacoes`( `idusuario`, `notificacao`, `data`) VALUES (?,?,?)";
			 PreparedStatement st5 = con.prepareStatement(sql5);
			 st5.setString(1, matricula);
			 st5.setString(2, "Devolu��o do livro :"+nomelivro+" !!");
			 st5.setString(3, datadevolucao);
			 st5.executeUpdate();
			
		
		 String sql = "DELETE FROM `reserva` WHERE `id`=?;";
		 PreparedStatement st = con.prepareStatement(sql);
		 st.setInt(1, numeroReserva);
		 st.executeUpdate();
		 
		 String sql1 = "SELECT `nome`,`status`,`quantidade` FROM `livro` WHERE isbn = '"+isbn+"'";
			PreparedStatement st1 = con.prepareStatement(sql1);
			ResultSet resultado = st1.executeQuery();
			while(resultado.next()){
				String quantidade = resultado.getString("quantidade");
				 qtd =  Integer.parseInt(quantidade);
				
					 
					 
					 
					 String sql2 = "UPDATE `livro` SET `quantidade`= ? WHERE `isbn`= ?";
					 PreparedStatement st2 = con.prepareStatement(sql2);
					 st2.setInt(1, qtd+1);
					st2.setString(2,isbn );
					 st2.executeUpdate();
					 
			}
			return "Devolu��o feita com sucesso";
			}catch(Exception e){
				return e.toString();
				
		

			}
		
		
		
	}
	
	public static String renovar(int id) throws SQLException{
		
		try{
		Connection con = Conexao.getConexao();
		java.util.GregorianCalendar gc = new java.util.GregorianCalendar();
		

		gc.add(java.util.GregorianCalendar.DAY_OF_MONTH, 7);

		String datadevolucao = new java.text.SimpleDateFormat("dd/MM/yyyy").format(gc.getTime());
		
		 String sql1 = "UPDATE `reserva` SET `datadevolucao`= ?  WHERE `id`= ?";
		 PreparedStatement st2 = con.prepareStatement(sql1);
		 st2.setString(1, datadevolucao);
		 st2.setInt(2, id);
		 st2.executeUpdate();
		 
		 return "Renovado com Sucesso";
		 
		 
		}catch(Exception e){
			
			 return e.toString();
			
		}
		
	}
	
	static int qtd;
	
	public static void inserir( Reserva reserva) throws SQLException{
		Connection con = Conexao.getConexao();
		PreparedStatement st = con.prepareStatement("INSERT INTO `reserva`(`isbn`, `matricula`, `dataretirada`, `datadevolucao`, `nome`)  VALUES (?,?,?,?,?);");
		st.setString(1,reserva.getIsbn());
		st.setString(2,reserva.getMatricula());
		st.setString(3,reserva.getDataretirada());
		st.setString(4,reserva.getDatadevolu��o());
		st.setString(5,reserva.getNome());
		st.execute();
		
	}
	
	public static String reservar( Reserva reserva, Connection con) throws SQLException{
		try{
		String sql = "SELECT `nome`,`status`,`quantidade` FROM `livro` WHERE isbn = '"+reserva.getIsbn()+"'";
		PreparedStatement st = con.prepareStatement(sql);
		ResultSet resultado = st.executeQuery();
		while(resultado.next()){
			String quantidade = resultado.getString("quantidade");
			 qtd =  Integer.parseInt(quantidade);
			 if(qtd >0){
				 
				 
				 
				 ReservaDAO.inserir(reserva);
				 PreparedStatement st3 = con.prepareStatement("INSERT INTO `notificacoes`(`idusuario`, `notificacao`,`data`) VALUES (?,?,?);");
					st3.setString(1,reserva.getMatricula());
					st3.setString(2,"livro : "+reserva.getNome()+" reservado!");
					st3.setString(3,reserva.getDataretirada());
					st3.execute();
				 
				 String sql1 = "UPDATE `livro` SET `quantidade`= ? WHERE `isbn`= ?";
				 PreparedStatement st2 = con.prepareStatement(sql1);
				 st2.setInt(1, qtd-1);
				st2.setString(2,reserva.getIsbn() );
				 st2.executeUpdate();
				 
			 }
			
		}
	
	
		return "Reserva realizada com sucesso!!";
		}catch(Exception e){
			return e.toString();
		}
	}

}
