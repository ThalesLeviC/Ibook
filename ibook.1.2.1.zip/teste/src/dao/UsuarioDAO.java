package dao;
import java.sql.*;
import classes.*;

public class UsuarioDAO {
	
	
	
	public static String inserir(Usuario usuario,Connection con) throws InstantiationException, IllegalAccessException{
		try{
			  
			PreparedStatement st = con.prepareStatement("INSERT INTO `aluno`(`matricula`, `nome`, `datanasc`, `celular`, `telefone`, `email`, `senha`) VALUES (?,?,?,?,?,?,?);");
			st.setString(1, usuario.getMatricula());
			st.setString(2, usuario.getNome());
			st.setString(3, usuario.getDatanascimento());
			st.setString(4, usuario.getCelular());
			st.setString(5, usuario.getTelefone());
			st.setString(6, usuario.getEmail());
			st.setString(7, usuario.getSenha());
			st.execute();
			
			
			return "Cadastro efetuado com sucesso!!!";
			
			
		}catch(Exception e){
			
			return e.toString();
			
		}
	}
}
