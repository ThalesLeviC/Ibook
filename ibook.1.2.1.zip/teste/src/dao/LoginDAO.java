package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {

	 
	private static PreparedStatement st = null;
	private static String usuario;
	
	
	public static String logar(String user ,String senha, Connection con) throws SQLException{
		
		if(user.contains("@ibook.com")){
		 st = con.prepareStatement("SELECT `senha` FROM `funcionario` WHERE`email` ='"+user+"';");
		 usuario ="Admin";
		 ResultSet resultado = st.executeQuery();
			while(resultado.next()){
				String senhaa = resultado.getString("senha");

				if(senhaa.equals(senha)){
					
					return "logado"+usuario;
				}else{
					return "Digite um usuario e senha correto";
				}
				
			}
			
		}else{
			st = con.prepareStatement("SELECT `senha` FROM `aluno` WHERE `matricula`= '"+user+"';");
			usuario ="Aluno";
			ResultSet resultado = st.executeQuery();
			
			
			while(resultado.next()){
		
			
				String senhaa = resultado.getString("senha");
				
				
				if(senhaa.equals(senha)){
					
					return "logado"+usuario;
				}else{
					return "Digite um usuario e senha correto";
				}
				
			}
		}
		
		
		return "n foi";
	}
}
