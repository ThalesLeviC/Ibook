package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import classes.*;

public class LancarNotaDAO {
	public static String inserir(LancarNota nota,Connection con) throws InstantiationException, IllegalAccessException{
		try{
			
			
			PreparedStatement st = con.prepareStatement("INSERT INTO `pedidos`(`numeronota`, `isbn`,`quantidade`,`valor`,`data`) VALUES (?,?,?,?,?)");
			st.setString(1,nota.getNumerodanota());
			st.setString(2, nota.getIsbn());
			st.setString(3,nota.getQuantidade());
			st.setString(4, nota.getValor());
			st.setString(5, nota.getData());
			st.execute();
			
			
			return "Cadastro efetuado com sucesso!!!";
			
			
		}catch(Exception e){
			
			return e.toString();
			
		}
	}

}
