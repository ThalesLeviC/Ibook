package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import classes.Admin;

public class AdminDAO {
	public static String inserir(Admin admin,Connection con) throws InstantiationException, IllegalAccessException{
		try{
			  
			PreparedStatement st = con.prepareStatement("INSERT INTO `funcionario`( `nome`, `cpf`, `email`, `telefone`, `celular`, `senha`) VALUES (?,?,?,?,?,?);");
			st.setString(1, admin.getNome());
			st.setString(2, admin.getCpf());
			st.setString(3, admin.getEmail());
			st.setString(4, admin.getTelefone());
			st.setString(5, admin.getCelular());
			st.setString(6, admin.getSenha());
			st.execute();
			
			
			return "Cadastro efetuado com sucesso!!!";
			
			
		}catch(Exception e){
			
			return e.toString();
			
		}
	}

}
